/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.company.nlp

import org.apache.nlpcraft.model.{NCIntentMatch, NCIntentRef, NCIntentSample, NCIntentTerm, NCModelFileAdapter, NCResult, NCToken}

/**
 * Model implementation that loads its static configuration from `template_model.yaml`
 * file. This class provides implementation for the model configuration that cannot be expressed
 * in a static JSON or YAML configuration file. This class (model) will be loaded and hosted by data probe.
 * <p>
 * Note that model is required to have at least no-arg constructor so that data probe can deploy it through reflection.
 * You can also provide model factories in data probe configuration to abstract out model creation.
 *
 * @see org.apache.nlpcraft.model.factories.basic.NCBasicModelFactory
 * @see org.apache.nlpcraft.model.factories.spring.NCSpringModelFactory
 */
class TemplateModel extends NCModelFileAdapter("template_model.yaml") {
    /**
     * A callback for `intentId` intent. This method will be called if and when `intentId` intent
     * is determined to be the best match for the user input. The intent itself is defined in
     * `template_model.yaml` file.
     * <p>
     * Annotation `NCIntentSample` provides the list of possible user inputs that should match
     * this intent (and hence cause this callback to be called). The same annotation(s) is used by
     * auto-validator for the model. See `NCTestAutoModelValidator` for details.
     *
     * @param ctx The entire context of this intent match. Contains all information about user and user input
     *      in its raw and fully parsed form including named entities, conversation context, etc.
     * @param tok Token annotated with `NCIntentTerm` annotation. See intent definition for the
     *      referenced token element.
     * @return Intent result as an instance of `NCResult` class.
     * @see org.apache.nlpcraft.model.tools.test.NCTestAutoModelValidator
     */
    @NCIntentRef("intentId") // ID of the intent defined in `template_model.yaml` file.
    @NCIntentSample( // List of user inputs that should match this `intentId`.
        Array(
            "the some word1",
            "some word2",
            "a word1",
            "the word2"
        )
    )
    def onMatch(ctx: NCIntentMatch, @NCIntentTerm("element") tok: NCToken): NCResult = {
        // TODO: add the actual intent logic here.

        // As a placeholder - just return an echo string.
        NCResult.text(
            s"Word `${tok.getOriginalText}` found in text: `${ctx.getContext.getRequest.getNormalizedText}`"
        )
    }
}
